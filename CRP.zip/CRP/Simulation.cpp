#include "Simulation.h"
#include <string>
#include <sstream>
#include <pthread.h>
#include <thread>
#include <unistd.h>
#include <mutex>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <chrono>
#define MAXLEN 1000000
#define CAS __sync_bool_compare_and_swap


#include "tensorflow/core/public/session.h"
#include "tensorflow/core/platform/env.h"
#include "tensorflow/core/protobuf/meta_graph.pb.h"
#include "tensorflow/cc/client/client_session.h"
#include "tensorflow/cc/ops/standard_ops.h"
#include "tensorflow/core/framework/tensor.h"
#include <iostream>
using namespace std;
using namespace tensorflow;
std::mt19937 Random::generator(0);


std::vector<int> Simulator::PerformOnlyPacketClassification(TupleSpaceSearch& classifier, std::map<std::string, std::string>& summary){

	std::chrono::time_point<std::chrono::steady_clock> start, end, st1, ed1;
	std::chrono::duration<double> elapsed_seconds,sum_time(0);
	std::chrono::duration<double,std::milli> elapsed_milliseconds;

	int ed60 = ruleset.size()*0.6, ed80 = ruleset.size()*0.8, ed100 = ruleset.size();
	cal_dis(classifier);
        classifier.ConstructClassifier(std::vector<Rule>(ruleset.begin(), ruleset.begin()+ed80));

	start = std::chrono::steady_clock::now();
	int update = 0;
	for (int i = ed80+1; i < ed100; i++) {classifier.InsertRule(ruleset[i]); update++;}
	end = std::chrono::steady_clock::now();
	elapsed_milliseconds = end-start;
	printf("\tUpdate time: %fms Rule: %d Speed: %.4f us\n", elapsed_milliseconds.count(),
    	                                 ruleset.size(), elapsed_milliseconds.count()/update*1000);

	
	printf("\tSize(bytes): %d B\n", classifier.MemSizeBytes());
	

	for (int i = 0; i < packets.size(); i++) {
		start = std::chrono::steady_clock::now();
		int ans = classifier.ClassifyAPacket(packets[i]);
		end = std::chrono::steady_clock::now();
		elapsed_seconds = end - start;
		sum_time += elapsed_seconds;
	}

	printf("\tClasstime: %fs Packet: %d Throughput %.4f Kpps\n", sum_time.count(), packets.size(),
		                                                     packets.size()/(sum_time.count()*1000));


	std::vector<int> results;
    return results;
}



void w_update(int update_times,std::vector<int> &que) {
        int tot = update_times/2;
        int a = 1;
        int b = 2;
        for(int i = 0; i < tot; i++){
                que.push_back(a);
                que.push_back(b);
        }
        return;
}



std::mutex g_lock;
std::mutex lock;
int exit_flag = 0;


int tot_rule ,tot_packet;

void Simulator::cal_dis(TupleSpaceSearch &classifier) {

    const string pathToGraph = "./model/combined_model.pb";
    const string checkpointPath = "./model/model.ckpt";

    auto session = NewSession(SessionOptions());
    if (session == nullptr) {
        throw runtime_error("Could not create tensorflow session");
    } else {
        std::cout << "Session created successfully" << std::endl;
    }

    Status status;
    // Load the protobuf graph
    GraphDef graph_def;
    status = ReadBinaryProto(Env::Default(), pathToGraph, &graph_def);
    if (!status.ok()) {
        throw runtime_error("Error reading graph definition");
    }
    else {
        std::cout << "Load graph protobuf successfully" << std::endl;
    }

    // Add the graph to the session
    status = session->Create(graph_def);
    if (!status.ok()) {
        throw runtime_error("Error ceating graph");
    }
    else {
        std::cout << "Add graph to session successfully" << std::endl;
    }
    tensorflow::Tensor input_tensor(tensorflow::DT_FLOAT, tensorflow::TensorShape({1,33,33,1}));
    auto input_tensor_mapped = input_tensor.tensor<float,4>();

    memset(classifier.now_dis, 0, sizeof(classifier.now_dis));
    for (auto rt: ruleset) {
        classifier.now_dis[rt.prefix_length[0]][rt.prefix_length[1]]++;
    }

    int max_val = classifier.now_dis[0][0];
    for(int i = 0 ; i <33; i++){
        for(int j =0; j <33; j++){
                if (classifier.now_dis[i][j] > max_val)
                        max_val  = classifier.now_dis[i][j];
        }
    }
    
    for(int i = 0; i <33; i++){
	for(int j = 0; j <33; j++){
            input_tensor_mapped (0,i,j,0) = (classifier.now_dis[i][j]*255)/max_val;
	}
    }
    std::cout << "Finish input data" << std::endl;

    std::vector<tensorflow::Tensor> finalOutput;
    std::string InputName = "input";
    std::string OutputName = "result";
    vector<std::pair<string, Tensor>> inputs;
    inputs.push_back(std::make_pair(InputName,input_tensor));

    session->Run(inputs,{OutputName},{},&finalOutput);
    std::cout << "Finish run" << std::endl;

    const Eigen::TensorMap<Eigen::Tensor<float, 1, Eigen::RowMajor>, Eigen::Aligned>& prediction = finalOutput[0].flat<float>();
    const long count = prediction.size();
    float low_bound = 0.0;
    int biggest_location = 0;
    for (int i = 0; i < count; ++i) {
        const float value = prediction(i);
        if(value > low_bound){
            low_bound = value;
            biggest_location = i;
        }
        //cout<<value<<endl;
    }
    //std::cout<<"biggest_location: "<<biggest_location<<std::endl;
    session->Close();
    std::cout << "Close session" << std::endl;


    char *filePath = "./label";
    ifstream file;
    file.open(filePath,ios::in);

    if(!file.is_open())
        std::cout<<"wrong label file"<<endl;
    std::string strLine;
    int line_num = 0;
    while(getline(file,strLine)){
        if(strLine.empty())
            continue;
        if(line_num == biggest_location){
            //std::cout<<strLine<<endl;
            istringstream str(strLine);
            string spx, spy;
            int iter = 0;
            while(str.good()){
                if(iter == 0){
                    getline(str,spx, ';');
                    cout<<"spx:"<<spx<<endl;
		    classifier.spx.clear();
                    classifier.workx(spx);
                }
                else{
		    getline(str,spy, ';');
                    cout<<"spy:"<<spy<<endl;
		    classifier.spy.clear();
                    classifier.worky(spy);
                }
                iter++;
            }
            break;
         }
         line_num++;
    }
    return;
}



void Simulator::monitor_new(TupleSpaceSearch &classifier){
    while(1){
       std::cout<<"monitor"<<std::endl;
       usleep(3000000);
       std::vector<Rule> ruleset = classifier.GetRules();
       memset(classifier.now_dis, 0, sizeof(classifier.now_dis));
       for (auto rt: ruleset) {
           classifier.now_dis[rt.prefix_length[0]][rt.prefix_length[1]]++;
       }
      int max_val = classifier.now_dis[0][0];
      for(int i = 0 ; i <33; i++){
          for(int j =0; j <33;j++){
                if (classifier.now_dis[i][j] > max_val)
                        max_val  = classifier.now_dis[i][j];
          }
      }

     for(int i = 0 ; i <33; i++)
        for(int j =0; j <33;j++)
             classifier.now_dis[i][j] = (classifier.now_dis[i][j]*255)/max_val;

       int k = 0, id = 0;
       int tk[74] = {0};
       int d1[9][9], d2[9][9];
       for (int i = 0; i <= 32; i++){
           for (int j = 0; j <= 32; j++) {
               d1[i/4][j/4]+=classifier.last_dis[i][j];
               d2[i/4][j/4]+=classifier.now_dis[i][j];
           }
       }
       for (int i = 0; i < 9; i++) {
           for (int j = 0; j < 8; j++) {
               int x = d1[i][j] > d1[i][j+1];
               int y = d2[i][j] > d2[i][j+1];
               tk[k++] = (x^y);
           }
       }
       int ans = 0;
       for (int i = 0; i < k; i++) ans+=tk[i];
       if(ans > 15){
           const string pathToGraph = "./model/combined_model.pb";
   	   const string checkpointPath = "./model/model.ckpt";

           auto session = NewSession(SessionOptions());
   	    if (session == nullptr) {
       		throw runtime_error("Could not create tensorflow session");
   	    } else {
       		std::cout << "Session created successfully" << std::endl;
   	    }

   	    Status status;
   	    // Load the protobuf graph
   	    GraphDef graph_def;
   	    status = ReadBinaryProto(Env::Default(), pathToGraph, &graph_def);
   	    if (!status.ok()) {
       		throw runtime_error("Error reading graph definition");
   	    }
   	    else {
       		std::cout << "Load graph protobuf successfully" << std::endl;
   	    }

   	    // Add the graph to the session
   	    status = session->Create(graph_def);
   	    if (!status.ok()) {
       		throw runtime_error("Error ceating graph");
   	    }
   	    else {
       		std::cout << "Add graph to session successfully" << std::endl;
   	    }
   	    tensorflow::Tensor input_tensor(tensorflow::DT_FLOAT, tensorflow::TensorShape({1,33,33,1}));
   	    auto input_tensor_mapped = input_tensor.tensor<float,4>();
           //input data
           //float input_array[128][128];
           for(int i = 0 ; i <33; i++)
               for(int j =0; j <33;j++)
                   input_tensor_mapped (0,i,j,0) = classifier.now_dis[i][j];

           std::cout << "Finish input data" << std::endl;
           //std::cout << input_tensor.TotalBytes()<<endl;

           std::vector<tensorflow::Tensor> finalOutput;
           std::string InputName = "input";
           std::string OutputName = "result";
           vector<std::pair<string, Tensor>> inputs;
           inputs.push_back(std::make_pair(InputName,input_tensor));

           session->Run(inputs,{OutputName},{},&finalOutput);
           std::cout << "Finish run" << std::endl;

           //cout<<finalOutput.size()<<endl;
           //auto result_map = finalOutput[0].tensor<float,1>();
           //cout << "result: " <<result_map(0,0)<<endl;
           const Eigen::TensorMap<Eigen::Tensor<float, 1, Eigen::RowMajor>, Eigen::Aligned>& prediction = finalOutput[0].flat<float>();
           const long count = prediction.size();
           float low_bound = 0.0;
           int biggest_location = 0;
           for (int i = 0; i < count; ++i) {
               const float value = prediction(i);
               if(value > low_bound){
		   low_bound = value;
                   biggest_location = i;
		}
               //cout<<value<<endl;
           }
           session->Close();
           std::cout << "Close session" << std::endl;
       
   	    char *filePath = "./label";
  	    ifstream file;
   	    file.open(filePath,ios::in);

   	    if(!file.is_open())
               std::cout<<"wrong label file"<<endl;
   	    std::string strLine;
   	    int line_num = 0;
   	    while(getline(file,strLine)){
       		if(strLine.empty())
           	continue;
       		if(line_num == biggest_location){
           	//std::cout<<strLine<<endl;
           	    istringstream str(strLine);
           	    string spx, spy;
           	    int iter = 0;
           	    while(str.good()){
               		if(iter == 0){
                   		getline(str,spx, ';');
                   		cout<<"spx:"<<spx<<endl;
				classifier.spx.clear();
                   		classifier.workx(spx);}
               		else{
       	    		getline(str,spy, ';');
                   		cout<<"spy:"<<spy<<endl;
				classifier.spy.clear();
                   		classifier.worky(spy);}
               		iter++;
           	    }
           	    break;
       		}
        	line_num++;
           }
	   //reconstruct of the hash tables
           
           g_lock.lock();
	   std::vector<Rule> new_ruleset = classifier.GetRules();
	   classifier.Destroy();
	   classifier.ConstructClassifier(new_ruleset);
	   g_lock.unlock();
	   
	   //update the distribution
	   for (int i = 0; i <= 32; i++){
               for (int j = 0; j <= 32; j++) {
                   classifier.last_dis[i][j] = classifier.now_dis[i][j];
           }
       	}
   	//return;
       }
  
   }
}





void Simulator::update(TupleSpaceSearch &classifier){
        std::chrono::duration<double> elapsed_seconds,elapsed_seconds1;
        std::chrono::time_point<std::chrono::steady_clock> start,end,start1,end1;

        int rule80 = (int)tot_rule*0.8;
        int dis = tot_rule-rule80;
        int t = 10;//update time per second
	
        for(int i = 0 ; i < 6; i++){
                        std::chrono::duration<double> sum_time(0);
                        int update = 0;
                        int get = 0;
                        std::vector<int> que;
                        //initQue(t,que);
                        w_update(t,que);

                        unsigned int classify_packet_pre = 0;
                        unsigned int classify_packet_after = 0;

                        std::chrono::duration<double> sum_time1(0);
                        start1 = std::chrono::steady_clock::now();
                        for(int j = 0; j <t; j++){
                            if(get == 0){
                                g_lock.lock();
                                classify_packet_pre = classifier.total_classify;
                                g_lock.unlock();
                                get = 1;
                            }
                            start = std::chrono::steady_clock::now();
                            int id;
                            id = que[j];
                            //printf("id:%d\n",id);
                            if (id == 1) {
                                    //printf("update insertion\n");
                                    int ran = rand()%dis + rule80;
                                    g_lock.lock();
                                    classifier.InsertRule(ruleset[ran]);
                                    g_lock.unlock();
                                    update++;
                                    end = std::chrono::steady_clock::now();
                            }
                            if (id == 2) {
                                    //printf("update deletion\n");
                                    int ran = rand()%dis + rule80;
                                    g_lock.lock();
                                    classifier.DeleteRule(ran);
                                    g_lock.unlock();
                                    update++;
                                    end = std::chrono::steady_clock::now();
                            }
                            elapsed_seconds = end - start;
                            sum_time += elapsed_seconds;
                            if(sum_time.count() >= 1.000)
                                 break;
                        }

                        if(sum_time.count() <1.000)
                            usleep(1000000-(int)(sum_time.count()*1000000));
                        /*
                        while(sum_time.count() <1.000){
                                start = std::chrono::steady_clock::now();
                                end = std::chrono::steady_clock::now();
                                elapsed_seconds = end - start;
                                sum_time += elapsed_seconds;
                        }
                        */
                        end1 = std::chrono::steady_clock::now();
                        elapsed_seconds1 = end1 - start1;
                        sum_time1 += elapsed_seconds1;
                        g_lock.lock();
                        classify_packet_after = classifier.total_classify;
                        g_lock.unlock();
                        int total_packets = classify_packet_after - classify_packet_pre;
                        printf("update_speed:%.2fKups  ",(float)t/1000);
                        printf("avg_time:%.4f  throughput:%.3f Kpps\n",sum_time1.count()/total_packets *1000000, (float)total_packets/1000);
                        t*=10;
                }
                exit_flag = 1;
	

        return;
}

std::vector<int> Simulator::PerformPacketClassificationUpdate(TupleSpaceSearch& classifier, std::map<std::string, std::string>& summary) {

        int tot_cnt = 0;

        tot_rule = ruleset.size(), tot_packet = packets.size();
	cal_dis(classifier);
        classifier.ConstructClassifier(ruleset);


        std::thread t1(&Simulator::update,this,std::ref(classifier));
        std::thread t2(&Simulator::monitor_new,this,std::ref(classifier));
        t1.detach();
        t2.detach();

        std::chrono::duration<double> elasped_seconds;
        std::chrono::time_point<std::chrono::steady_clock> start,end;
        //std::chrono::duration<double> sum_time(0);

        std::vector<int> results;
        int pac = 0;
        while(!exit_flag) {
                //printf("classify\n");
                for(int i = 0; i< tot_packet; i++){
                        g_lock.lock();
                        classifier.ClassifyAPacket(packets[i]);
                        classifier.total_classify++;
                        g_lock.unlock();

                }

    }
    return results;
}





