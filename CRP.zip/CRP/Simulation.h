#ifndef  SIMULATION_H
#define  SIMULATION_H

#include "ElementaryClasses.h"
#include "Utilities/MapExtensions.h"
#include "CRP/CRP.h"
#include <map>
#include <unordered_map>
#include <string.h>

class Simulator{
public:
	Simulator(){}
	~Simulator(){}
	Simulator(const std::vector<Rule>& ruleset) :ruleset(ruleset) {}
	Simulator(const std::vector<Rule>& ruleset, const std::vector<Packet>& packets) :ruleset(ruleset), packets(packets) {}


	std::vector<int>  PerformOnlyPacketClassification(TupleSpaceSearch& classifier, std::map<std::string, std::string>& summary);
	std::vector<int>  PerformPacketClassificationUpdate(TupleSpaceSearch& classifier, std::map<std::string, std::string>& summary);
	void cal_dis(TupleSpaceSearch &classifier);
	void update(TupleSpaceSearch & classifier);
	void monitor_new(TupleSpaceSearch & classifier);

private:
	std::vector<Rule> ruleset;
	std::vector<Packet> packets;
};

#endif
