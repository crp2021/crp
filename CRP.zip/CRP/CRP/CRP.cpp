#include "CRP.h"

// Values for Bernstein Hash
#define HashBasis 5381
#define HashMult 33
int vis[33][33];
void Tuple::Insertion(const New_Rule& r) {
	cmap_node * new_node = new cmap_node(r); /*key & rule*/
	cmap_insert(&map_in_tuple, new_node, HashRule(r));

}

void Tuple::Deletion(const New_Rule& r) {
	//find node containing the rule
	unsigned int hash_r = HashRule(r);
	cmap_node * found_node = cmap_find(&map_in_tuple, hash_r);
	while (found_node != nullptr) {
		if (found_node->priority == r.priority) {
			cmap_remove(&map_in_tuple, found_node, hash_r);
			break;
		}
		found_node = found_node->next;
	}

}

int Tuple::WorstAccesses() const {
	// TODO
	return 1;//cmap_largest_chain(&map_in_tuple);
}

uint32_t avg_hash_time = 0;
float avg_hash_total = 0;;
uint32_t avg_cmp_time = 0;
float avg_cmp_total = 0;
int Tuple::FindMatchPacket(const Packet& p, int& cmp)  {
	access++;
/*

	std::chrono::time_point<std::chrono::steady_clock> start1, end1, start2, end2; 
	std::chrono::duration<double> duration_1,duration_2;

	start1 = std::chrono::steady_clock::now();
*/
	cmap_node *found_node;
/*
	Packet new_packet, new_packet_2;
	new_packet = p;
	new_packet_2 = p;
	for(int z = 0 ; z <1000; z++){
*/
	    found_node = cmap_find(&map_in_tuple, HashPacket(p));
/*	}
	end1 = std::chrono::steady_clock::now();
	duration_1 = end1 - start1;
	float avg = (float)std::chrono::duration_cast<std::chrono::nanoseconds>(duration_1).count()/1000;
	//printf("hash:%f\n",avg);
	avg_hash_time++;
	avg_hash_total+=avg;
	if(avg_hash_time == 10000)
	    printf("total_hash_avg:%f\n",avg_hash_total/avg_hash_time);
*/
	int priority = -1;
/*
	cmap_node *pre = found_node;
	int q = 0;
	start2 = std::chrono::steady_clock::now();
*/
	//if(found_node != NULL){
//	for(int z = 0; z<100;z++){
//	    found_node = pre;
	while (found_node != nullptr) {
	    if (found_node->rule_ptr->MatchesPacket(p)) {	
			cmp++;
			////total_cmp++;
			priority = std::max(priority, found_node->rule_ptr->priority);
			//printf("p:%d\n",priority);
			//new_packet_2[0]++;
			break;
	    }
	    else{
			cmp++;
			//new_packet_2[0]++;
			////total_cmp++;
	    }
		found_node = found_node->next;
	}
    
//	end2 = std::chrono::steady_clock::now();
//	duration_2 = end2-start2;
//	float avg_2 = (float)std::chrono::duration_cast<std::chrono::nanoseconds>(duration_2).count()/q;
	//printf("q:%d,cmp:%f\n",q,avg_2);
	
//	avg_cmp_time++;
//	avg_cmp_total +=avg_2;
//	if(avg_cmp_time == 10000)
//	    printf("total_cmp_avg:%f\n",avg_cmp_total/avg_cmp_time);
//	}
	////printf("total_cmp:%d\n",total_cmp);
	//printf("priority:%d\n",priority);
	return priority;

}


uint32_t inline Tuple::HashRule(const New_Rule& r) const {
	uint32_t hash = 0;
	uint32_t max_uint = 0xFFFFFFFF;
	for (size_t i = 0; i < dims.size(); i++) {
		uint32_t mask = lengths[i] != 32 ? ~(max_uint >> lengths[i]) : max_uint;
		if(i == 0)
		    hash = hash_add(hash,r.rip[0] & mask);
		if(i == 1)
		    hash = hash_add(hash,r.rip[2] & mask);

	}
	return hash_finish(hash, 16);
}

uint32_t inline Tuple::HashPacket(const Packet& p) const {
	uint32_t hash = 0;
	uint32_t max_uint = 0xFFFFFFFF;

	for (size_t i = 0; i < dims.size(); i++) {
		uint32_t mask = lengths[i] != 32 ? ~(max_uint >> lengths[i]) : max_uint;
		hash = hash_add(hash, p[dims[i]] & mask);
	}
	return hash_finish(hash, 16);

}


unsigned int TupleSpaceSearch::cal(unsigned int d, int flag) {
	
	if (flag == 0) {
		int tx = spx.size() - 1;
		for (int i = tx; i >= 0; i--) {
			if (d >= spx[i]) return spx[i];
		}
		return 0;
	}
	else {
		int tx = spy.size() - 1;
		for (int i = tx; i >= 0; i--) {
			if (d >= spy[i]) return spy[i];
		}
		return 0;
	}
	
}

int work(const std::vector<unsigned int> &lengths, unsigned int id) {
	if(vis[lengths[0]][lengths[1]] != -1) return vis[lengths[0]][lengths[1]];
	else {
		vis[lengths[0]][lengths[1]] = id;
		return id;
	}

}
void TupleSpaceSearch::ConstructClassifier(const std::vector<Rule>& r){
	
	memset(vis, -1, sizeof(vis));
	dims.push_back(FieldSA);
	dims.push_back(FieldDA);
	rule_map.reserve(r.size() + 100000);
	rule_tuple.clear();
	for (int i = 0; i < 1024; i++) {
		max_pri.push_back(-1);
	}
	
	for (const auto& Rule : r) {
		//printf("%d\n",sizeof(Rule));
		InsertRule(Rule);
	}
	//printf("size:%d\n",rule_tuple.size());
	
}

//int total_hash = 0;
int TupleSpaceSearch::ClassifyAPacket(const Packet& packet) {
	/*
	std::chrono::time_point<std::chrono::steady_clock> start1, end1; 
	std::chrono::duration<double> duration_1;

	start1 = std::chrono::steady_clock::now();
	*/
	int priority = -1;
	int q = 0;
	int total_hash = 0;
	int total_cmp = 0;
	for (int i = 0; i < rule_tuple.size(); ++i) {
		q++;
		total_hash++;
		int cmp = 0;
		if (max_pri[i] == -1 || priority >= max_pri[i]) break;
		auto result = rule_tuple[i].FindMatchPacket(packet,cmp);
		priority = std::max(priority, result);
		total_cmp += cmp;
	}
	/*
	end1 = std::chrono::steady_clock::now();
	duration_1 = end1 - start1;
	float avg = (float)std::chrono::duration_cast<std::chrono::nanoseconds>(duration_1).count()/1000;
	printf("%f\n",avg);
	*/
	//printf("tuple_number:%d\n",q);
	/*
	int query = 0;
	for (auto& tuple : all_tuples) {
		auto result = tuple.second.FindMatchPacket(packet);
		priority = std::max(priority, result);
		query++;
	}
	QueryUpdate(query);
	*/
	//printf("%d\n",total_cmp);
	//printf("%d\n",priority);
	return priority;
}
void TupleSpaceSearch::DeleteRule(size_t i) {

	if (i < 0 || i >= rules.size()) {
		//printf("Warning index delete rule out of bound: do nothing here\n");
		//printf("%lu vs. size: %lu", i, rules.size());
		return;
	}
	int id = rules[i].priority;
	rule_map[id] = -1;
	std::vector<unsigned int> lengths;
	for (int d = 0; d < dims.size(); d++) {
		lengths.push_back(cal(rules[i].prefix_and_proto[d], d));
	}
	id = work(lengths, rule_tuple.size());
	rule_tuple[id].Deletion(rules[i]);

	if (i != rules.size() - 1)
		rules[i] = std::move(rules[rules.size() - 1]);
	rules.pop_back();
	
	if (i != old_rules.size() - 1)
		old_rules[i] = std::move(old_rules[old_rules.size() - 1]);
	old_rules.pop_back();

}
void TupleSpaceSearch::InsertRule(const Rule& rule) {

	struct New_Rule new_rule;
	new_rule.priority = rule.priority;

	uint32_t prefix1 = rule.prefix_length[0];
	uint32_t prefix2 = rule.prefix_length[1];
	new_rule.prefix_and_proto[0] = prefix1;
	new_rule.prefix_and_proto[1] = prefix2;


	new_rule.rip[0]= rule.range[0][0];
	new_rule.rip[1]= rule.range[0][1];
	new_rule.rip[2]= rule.range[1][0];
	new_rule.rip[3]= rule.range[1][1];

	new_rule.port[0] = rule.range[2][0];
	new_rule.port[1] = rule.range[2][1];
	new_rule.port[2] = rule.range[3][0];
	new_rule.port[3] = rule.range[3][1];
    
	new_rule.prefix_and_proto[2] = rule.range[4][0];
	new_rule.prefix_and_proto[3] = rule.range[4][1];
	
	std::vector<unsigned int> lengths;
	for (int d = 0; d < dims.size(); d++) {
		lengths.push_back(cal(new_rule.prefix_and_proto[d], d));
	}
	unsigned int id = work(lengths, rule_tuple.size());
	if(max_pri[id] == -1) {
		rule_tuple.push_back(Tuple(dims, lengths, new_rule));
		max_pri[id] = rule.priority;
	}
	else {
		rule_tuple[id].Insertion(new_rule);
		max_pri[id] = std::max(max_pri[id], new_rule.priority);
	}
	rules.push_back(new_rule);
	old_rules.push_bacl(rule);
	rule_map[new_rule.priority] = rules.size() - 1;
}

int TupleSpaceSearch::WorstAccesses() const {
	int cost = 0;
	for (auto pair : all_tuples) {
		cost += pair.second.WorstAccesses() + 1;
	}
	return cost;
}
