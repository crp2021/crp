#ifndef  TUPLE_H
#define  TUPLE_H

#define POINTER_SIZE_BYTES 4

#include "cmap.h"
#include <unordered_map>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iostream>
#include "unistd.h"
#include "../Utilities/MapExtensions.h"

struct Tuple {
public:
	Tuple(const std::vector<int>& dims, const std::vector<unsigned int>& lengths, const New_Rule& r) : dims(dims), lengths(lengths) {
		for (int w : lengths) {
			tuple.push_back(w);
		}
		cmap_init(&map_in_tuple);
		Insertion(r);
		access = 0;
	}
	void Destroy() {
		cmap_destroy(&map_in_tuple);
	}

	bool IsEmpty() { return CountNumRules() == 0; }

	int FindMatchPacket(const Packet& p, int& cmp);
	void Insertion(const New_Rule& r);
	void Deletion(const New_Rule& r);
	int WorstAccesses() const;
	int CountNumRules() const  {
		return cmap_count(&map_in_tuple);
	}
	int CountBucket() const{
		return cmap_array_size(&map_in_tuple)*5;
	}
	
	uint32_t MemSizeBytes(uint32_t ruleSizeBytes) const {
		return 	cmap_count(&map_in_tuple)* ruleSizeBytes + cmap_array_size(&map_in_tuple) * POINTER_SIZE_BYTES*5;	
	}

	void printsipdip() {
		//printf("sipdip: %d %d\n", sip_length, dip_length);
	}
	int access;
protected:
	bool inline IsPacketMatchToRule(const Packet& p, const New_Rule& r);
	unsigned int inline HashRule(const New_Rule& r) const;
	unsigned int inline HashPacket(const Packet& p) const;
	cmap map_in_tuple;

	std::vector<int> dims;
	std::vector<unsigned int> lengths;
	std::vector<int> tuple;
};

class TupleSpaceSearch{
public:

	virtual ~TupleSpaceSearch() {
		for (auto p : all_tuples) {
			p.second.Destroy();
		}
	}

	void ConstructClassifier(const std::vector<Rule>& r);
	int ClassifyAPacket(const Packet& one_packet);
	void DeleteRule(size_t i);
	void InsertRule(const Rule& one_rule);
	void workx(std::string &x) {
		//if (x.length() < 1) {
		//	spx.clear(); spx.push_back(0); spx.push_back(4); spx.push_back(16);
		//}
		//else {
			std::vector<std::string> tokens;
			Split(x,',',tokens);
			for (int i = 0; i < tokens.size(); i++) {
				int tx = 0;
				for (int j = 0; j < tokens[i].length(); j++) {
					tx = tx * 10 + tokens[i][j] - '0';
				}
				spx.push_back(tx);
			}
		//}
		//for (int i = 0; i < spx.size(); i++) {
		//	printf("%d ", spx[i]);
		//}
		//printf("\n");
	}
	void worky(std::string &y) {
		//if (y.length() < 1) {
		//	spy.clear(); spy.push_back(0); spy.push_back(4); spy.push_back(16);
		//}
		//else {
			std::vector<std::string> tokens;
			Split(y,',',tokens);
			for (int i = 0; i < tokens.size(); i++) {
				int ty = 0;
				for (int j = 0; j < tokens[i].length(); j++) {
					ty = ty * 10 + tokens[i][j] - '0';
				}
				spy.push_back(ty);
			}
		//}
		//for (int i = 0; i < spy.size(); i++) {
		//	printf("%d ", spy[i]);
		//}
		//printf("\n");
	}
        std::vector<Rule> GetRules(){return old_rules;}

 	void Destroy() {
    		for (auto p : all_tuples) {
                        p.second.Destroy();
                }
                all_tuples.clear();
                for (auto p: rule_tuple) {
      			p.Destroy();
                }
                rule_tuple.clear();
                rule_map.clear();
                max_pri.clear();
                old_rules.clear();
                max_pri.clear();
                dims.clear();
  	}
	
        int MemoryAccess() const {
		return WorstAccesses();
	}
	virtual int WorstAccesses() const;
	uint32_t MemSizeBytes() const {
		std::ifstream file("/proc/self/statm");
		std::size_t memory;
		file >> memory;
		file >> memory;
		return memory * getpagesize();
	}
	virtual int GetNumberOfTuples() const {
		return rule_tuple.size();
	}
	size_t NumTables() const { return GetNumberOfTuples(); }
	size_t RulesInTable(size_t index) const { return 0; } // TODO : assign some order
	unsigned int cal(unsigned int d, int flag);
	int total_classify;
	std::vector<int> spx,spy;
	int last_dis[33][33];
	int now_dis[33][33];
        int flag;

protected:
	uint64_t inline KeyRulePrefix(const Rule& r) {
		int key = 0;
		for (int d : dims) {
			key <<= 6;
			key += r.prefix_length[d];
		}
		return key;
	}
	std::unordered_map<uint64_t, Tuple> all_tuples;
	std::vector<Tuple> rule_tuple;
	std::vector<int> rule_map;
	std::vector<int> max_pri;
	std::vector<Rule> old_rules;
	std::vector<New_Rule> rules;
	std::vector<int> dims;

};



#endif
