#include "ElementaryClasses.h"
#include "IO/InputReader.h"
#include "IO/OutputWriter.h"
#include "Simulation.h"

#include "CRP/CRP.h"

#include <stdio.h>


#include <assert.h>
#include <memory>
#include <chrono>
#include <string>
#include <sstream>

using namespace std;

/*
vector<int> RunSimulatorClassificationTrial(Simulator& s, const string& name, PacketClassifier& classifier, vector<map<string, string>>& data);

pair< vector<string>, vector<map<string, string>>>  RunSimulatorOnlyClassification(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "");

vector<int> RunSimulatorClassificationUpdate(Simulator& s, const string& name, PacketClassifier& classifier, vector<map<string, string>>& data);

pair< vector<string>, vector<map<string, string>>>  RunSimulatorClassificationUpdate(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "");
*/
vector<int> RunSimulatorClassificationTrial(Simulator& s, const string& name, TupleSpaceSearch& classifier, vector<map<string, string>>& data);

pair< vector<string>, vector<map<string, string>>>  RunSimulatorOnlyClassification(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "");

vector<int> RunSimulatorClassificationUpdate(Simulator& s, const string& name, TupleSpaceSearch& classifier, vector<map<string, string>>& data);

pair< vector<string>, vector<map<string, string>>>  RunSimulatorClassificationUpdate(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "");


ClassifierTests ParseClassifier(const string& line); 
TestMode ParseMode(const string& mode);


int main(int argc, char* argv[]) {
	unordered_map<string, string> args = ParseArgs(argc, argv);

	string filterFile = GetOrElse(args, "f", "fw1_seed_1.rules");
	string packetFile = GetOrElse(args, "p", "Auto");
	string outputFile = GetOrElse(args, "o", "");

	string database = GetOrElse(args, "d", "");
	bool doShuffle = GetBoolOrElse(args, "Shuffle", true);

	//set by default
	ClassifierTests classifier = ParseClassifier(GetOrElse(args, "c", "PriorityTuple"));
	TestMode mode = ParseMode(GetOrElse(args, "m", "Classification"));

	int repeat = GetIntOrElse(args, "r", 1);
	
		
	if (GetBoolOrElse(args, "?", false)) {
		printf("Arguments:\n");
		printf("\t-f <file> Filter File\n");
		printf("\t-p <file> Packet File\n");
		printf("\t-o <file> Output File\n");
		printf("\t-c <classifier> Classifier\n");
		printf("\t-m <mode> Classification Mode\n");
		exit(0);
	}
	
	//assign mode and classifer
	vector<Rule> rules = InputReader::ReadFilterFile(filterFile);

	vector<Packet> packets;
	packets = InputReader::ReadPackets(packetFile);
	

	switch (mode)
	{
			case ModeClassification:
				RunSimulatorOnlyClassification(args, packets, rules, classifier, outputFile);
				break;
			case ModeUpdate:
				RunSimulatorClassificationUpdate(args, packets, rules, classifier, outputFile);
				break;
	}
 
	printf("Done\n");
	return 0;
}



//vector<int> RunSimulatorClassificationTrial(Simulator& s, const string& name, PacketClassifier& classifier, vector<map<string, string>>& data) {
vector<int> RunSimulatorClassificationTrial(Simulator& s, const string& name, TupleSpaceSearch& classifier, vector<map<string, string>>& data) {
	map<string, string> d = { { "Classifier", name } };
	auto r = s.PerformOnlyPacketClassification(classifier, d);
	data.push_back(d);
	return r;
}

pair< vector<string>, vector<map<string, string>>>  RunSimulatorOnlyClassification(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "") {
	Simulator s(rules, packets);

	vector<string> header = { "Classifier", "ConstructionTime(ms)", "ClassificationTime(s)", "Size(bytes)", "MemoryAccess", "Tables", "TableSizes", "TableQueries", "AvgQueries" };
	vector<map<string, string>> data;

	if (tests & ClassifierTests::TestPriorityTuple) {
		TupleSpaceSearch crp;
		RunSimulatorClassificationTrial(s, "PriorityTuple", crp, data);
	}

	if (outfile != "") {
		OutputWriter::WriteCsvFile(outfile, header, data);
	}
	return make_pair(header, data);
}

//vector<int> RunSimulatorClassificationUpdate(Simulator& s, const string& name, PacketClassifier& classifier, vector<map<string, string>>& data) {
vector<int> RunSimulatorClassificationUpdate(Simulator& s, const string& name, TupleSpaceSearch& classifier, vector<map<string, string>>& data) {
	map<string, string> d = { { "Classifier", name } };
	auto r = s.PerformPacketClassificationUpdate(classifier, d);
	data.push_back(d);
	return r;
}

pair< vector<string>, vector<map<string, string>>>  RunSimulatorClassificationUpdate(const unordered_map<string, string>& args, const vector<Packet>& packets, const vector<Rule>& rules, ClassifierTests tests, const string& outfile = "") {
	Simulator s(rules, packets);

	vector<string> header = { "Classifier", "ConstructionTime(ms)", "ClassificationTime(s)", "Size(bytes)", "MemoryAccess", "Tables", "TableSizes", "TableQueries", "AvgQueries" };
	vector<map<string, string>> data;

	if (tests & ClassifierTests::TestPriorityTuple) {
		TupleSpaceSearch crp;
		string x = GetOrElse(args, "x", "");
		string y = GetOrElse(args, "y", "");
		crp.workx(x);
		crp.worky(y);
		RunSimulatorClassificationUpdate(s, "PriorityTuple", crp, data);
	}

	if (outfile != "") {
		OutputWriter::WriteCsvFile(outfile, header, data);
	}
	return make_pair(header, data);
}

ClassifierTests ParseClassifier(const string& line) {
	vector<string> tokens;
	Split(line, ',', tokens);
	ClassifierTests tests = ClassifierTests::TestNone;

	for (const string& classifier : tokens) {
	
		if (classifier == "PriorityTuple") {
			tests = tests | TestPriorityTuple;
		}
		else if (classifier == "All") {
			tests = tests | TestAll;
		}
		else {
			printf("Unknown ClassifierTests: %s\n", classifier.c_str());
			exit(EINVAL);
		}
	}
	return tests;
}

TestMode ParseMode(const string& mode) {
	printf("%s\n", mode.c_str());
	if (mode == "Classification") {
		return ModeClassification;
	}
	else if(mode == "ClassificationUpdate"){
		return ModeUpdate;
	}
	else {
		printf("Unknown mode: %s\n", mode.c_str());
		exit(EINVAL);
	}
}
